class Tugas {
  int? id;
  String? judul;
  String? deskripsi;
  int? tenggat_waktu;

  Tugas({this.id, this.judul, this.deskripsi, this.tenggat_waktu});

  factory Tugas.fromJson(Map<String, dynamic> obj) {
    return Tugas(
        id: obj['id'],
        judul: obj['judul'],
        deskripsi: obj['deskripsi'],
        tenggat_waktu: obj['tenggat_waktu']
    );
  }
}
