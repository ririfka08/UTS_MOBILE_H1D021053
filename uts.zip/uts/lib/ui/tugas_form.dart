import 'package:flutter/material.dart';
import 'package:uts/model/tugas.dart';
import 'package:uts/model/tugas.dart';

class TugasForm extends StatefulWidget {
  Tugas? tugas;

  TugasForm({Key? key, this.tugas}) : super(key: key);

  @override
  _TugasFormState createState() => _TugasFormState();
}

class _TugasFormState extends State<TugasForm> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  String judul = "TAMBAH TUGAS";
  String tombolSubmit = "SIMPAN";

  final _judulTugasTextboxController = TextEditingController();
  final _deskripsiTugasTextboxController = TextEditingController();
  final _tenggat_waktuTugasTextboxController = TextEditingController();

  @override
  void initState() {
    super.initState();
    isUpdate();
  }

  isUpdate() {
    if (widget.tugas != null) {
      setState(() {
        judul = "UBAH TUGAS";
        tombolSubmit = "UBAH";
        _judulTugasTextboxController.text = widget.tugas!.judul!;
        _deskripsiTugasTextboxController.text = widget.tugas!.deskripsi!;
        _tenggat_waktuTugasTextboxController.text =
            widget.tugas!.tenggat_waktu.toString(); 38; });
    } else {
      judul = "TAMBAH TUGAS";
      tombolSubmit = "SIMPAN";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(judul)),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                _judulTugasTextField(),
                _deskripsiTugasTextField(),
                _tenggat_waktuTugasTextField(),
                _buttonSubmit()
              ],
            ),
          ),
        ),
      ),
    );
  }

  //Membuat Textbox Kode Tugas
  Widget _judulTugasTextField() {
    return TextFormField(
      decoration: const InputDecoration(labelText: "Judul Tugas"),
      keyboardType: TextInputType.text,
      controller: _judulTugasTextboxController,
      validator: (value) {
        if (value!.isEmpty) {
          return "Judul Tugas harus diisi";
        }
        return null;
      },
    );
  }

  //Membuat Textbox Deskripsi Tugas
  Widget _deskripsiTugasTextField() {
    return TextFormField(
      decoration: const InputDecoration(labelText: "Deskripsi Tugas"),
      keyboardType: TextInputType.text,
      controller: _deskripsiTugasTextboxController,
      validator: (value) {
        if (value!.isEmpty) {
          return "Deskripsi Tugas harus diisi";
        }
        return null;
      },
    );
  }

  //Membuat Textbox Tenggat Waktu Tugas
  Widget _tenggat_waktuTugasTextField() {
    return TextFormField(
      decoration: const InputDecoration(labelText: "Tenggat Waktu"),
      keyboardType: TextInputType.number,
      controller: _tenggat_waktuTugasTextboxController,
      validator: (value) {
        if (value!.isEmpty) {
          return "Tenggat waktu harus diisi";
        }
        return null;
      },
    );
  }

  //Membuat Tombol Simpan/Ubah
  Widget _buttonSubmit() {
    return OutlinedButton(
        child: Text(tombolSubmit),
        onPressed: () {
          var validate = _formKey.currentState!.validate();
        });
  }
}