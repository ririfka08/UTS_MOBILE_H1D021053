import 'package:flutter/material.dart';
import 'package:uts/model/tugas.dart';
import 'package:uts/ui/tugas_form.dart';

class TugasDetail extends StatefulWidget {
  Tugas? tugas;

  TugasDetail({Key? key, this.tugas}) : super(key: key);

  @override
  _TugasDetailState createState() => _TugasDetailState();
}

class _TugasDetailState extends State<TugasDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Tugas'),
      ),
      body: Center( child:
      Column(
        children: [
          Text(
            "Judul : ${widget.tugas!.judul}",
            style: const TextStyle(fontSize: 20.0),
          ),
          Text(
            "Deskripsi : ${widget.tugas!.deskripsi}",
            style: const TextStyle(fontSize: 18.0),
          ),
          Text(
            "Tenggat waktu :  ${widget.tugas!.tenggat_waktu.toString()}",
            style: const TextStyle(fontSize: 18.0),
          ),
          _tombolHapusEdit()
        ],
      ),
      ),
    );
  }

  Widget _tombolHapusEdit() {
    return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
    //Tombol Edit
    OutlinedButton(
    child: const Text("EDIT"),
    onPressed: () {
    Navigator.push(
    context,
    MaterialPageRoute(
    builder: (context) => TugasForm(
    tugas: widget.tugas!,
     )));
     }),
     //Tombol Hapus
     OutlinedButton(
     child: const Text("DELETE"), onPressed: () => confirmHapus()),
     ],
     );
     }

   void confirmHapus() {
     AlertDialog alertDialog = AlertDialog(
         content: const Text("Yakin ingin menghapus data ini?"),
     actions: [
     //tombol hapus
     OutlinedButton(
     child: const Text("Ya"),
     onPressed: () {},
     ),
     //tombol batal
     OutlinedButton(
     child: const Text("Batal"),
    onPressed: () => Navigator.pop(context),
    )
    ],
    );

    showDialog(builder: (context) => alertDialog, context: context);
  }
}
